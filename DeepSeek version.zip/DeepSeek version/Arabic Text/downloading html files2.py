import os
import requests
from bs4 import BeautifulSoup
from tqdm import tqdm

# Folder to save downloaded ayah HTML files
DOWNLOAD_FOLDER = os.path.expanduser('~/Downloads/Quran_Arabic_Text')
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

# List of surah transliterated names as used in dawateislami.net URLs, all 114 surahs
surah_names = [
"surah-abasa", "surah-abasa", "surah-ad-dahr", "surah-ad-dahr”,", "surah-ad-duha", "surah-ad-duha", "surah-ad-dukhan", "surah-ad-dukhan", "surah-al-adiyat", "surah-al-adiyat", "surah-al-ahqaf", "surah-al-ahqaf", "surah-al-ahzab", "surah-al-ahzab", "surah-al-ala", "surah-al-ala", "surah-al-alaq", "surah-al-alaq", "surah-al-anam", "surah-al-anam", "surah-al-anbiya", "surah-al-anbiya", "surah-al-anfal", "surah-al-anfal", "surah-al-ankabut", "surah-al-ankabut", "surah-al-araf", "surah-al-araf", "surah-al-asr", "surah-al-asr", "surah-al-baiyinah", "surah-al-baiyinah", "surah-al-balad", "surah-al-balad", "surah-al-baqarah", "surah-al-baqarah", "surah-al-buruj", "surah-al-buruj", "surah-al-fajr", "surah-al-fajr", "surah-al-falaq", "surah-al-falaq", "surah-al-fath", "surah-al-fath", "surah-al-fatihah", "surah-al-fatihah", "surah-al-fil", "surah-al-fil", "surah-al-furqan", "surah-al-furqan", "surah-al-ghashiyah", "surah-al-ghashiyah", "surah-al-hadid", "surah-al-hadid", "surah-al-hajj", "surah-al-hajj", "surah-al-haqqah", "surah-al-haqqah", "surah-al-hashr", "surah-al-hashr", "surah-al-hijr", "surah-al-hijr", "surah-al-hujurat", "surah-al-hujurat", "surah-al-humazah", "surah-al-humazah", "surah-al-ikhlas", "surah-al-ikhlas", "surah-al-imran", "surah-al-imran", "surah-al-infitar", "surah-al-infitar", "surah-al-inshiqaq", "surah-al-inshiqaq", "surah-al-isra", "surah-al-isra", "surah-al-jasia", "surah-al-jasia", "surah-al-jin", "surah-al-jin", "surah-al-jumuah", "surah-al-jumuah", "surah-al-kafiroon", "surah-al-kafiroon", "surah-al-kahf", "surah-al-kahf", "surah-al-kausar", "surah-al-kausar", "surah-al-lahab", "surah-al-lahab", "surah-al-lail", "surah-al-lail", "surah-al-maarij", "surah-al-maarij", "surah-al-maidah", "surah-al-maidah", "surah-al-maun", "surah-al-maun", "surah-al-mudassir", "surah-al-mudassir", "surah-al-mujadilah", "surah-al-mujadilah", "surah-al-mulk", "surah-al-mulk", "surah-al-muminun", "surah-al-muminun", "surah-al-mumtahinah", "surah-al-mumtahinah", "surah-al-munafiqun", "surah-al-mursalat", "surah-al-mutaffifin", "surah-al-muzzammil", "surah-al-qadr", "surah-al-qalam", "surah-al-qamar", "surah-al-qariah", "surah-al-qasas", "surah-al-qiyamah", "surah-al-taubah", "surah-al-waqiah", "surah-alam-nashrah", "surah-alam-nashrah", "surah-an-naba", "surah-an-nahl", "surah-an-najm", "surah-an-naml", "surah-an-nas", "surah-an-nasr", "surah-an-naziat", "surah-an-nisa", "surah-an-nur", "surah-ar-rad", "surah-ar-rahman", "surah-ar-rum", "surah-as-saff", "surah-as-saffat", "surah-as-sajdah", "surah-ash-shams", "surah-ash-shuara", "surah-ash-shura", "surah-at-taghabun", "surah-at-tahrim", "surah-at-takasur", "surah-at-takwir", "surah-at-talaq", "surah-at-tariq", "surah-at-tin", "surah-at-tur", "surah-az-zariyat", "surah-az-zilzal", "surah-az-zukhruf", "surah-az-zumar", "surah-fatir", "surah-fussilat", "surah-ghafir", "surah-hud", "surah-ibrahim", "surah-luqman", "surah-luqman", "surah-maryam", "surah-muhammad", "surah-nuh", "surah-qaf", "surah-quraish", "surah-saba", "surah-sad", "surah-taha", "surah-yasin", "surah-yunus", "surah-yusf", "", " 
]









# Number of ayahs in each surah exactly as per Quran
ayahs_per_surah = [
    7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
    123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
    112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
    34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
    54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
    60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
    14, 11, 11, 18, 12, 12, 30, 52, 52, 44,
    28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
    29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
    15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
    11, 8, 3, 9, 5, 4, 7, 3, 6, 3,
    5, 4, 5, 6
]

def fetch_and_save_ayah(surah_num, ayah_num):
    surah_name = surah_names[surah_num - 1]
    filename = f"{str(surah_num).zfill(3)}{str(ayah_num).zfill(3)}.html"
    filepath = os.path.join(DOWNLOAD_FOLDER, filename)

    if os.path.exists(filepath):
        return  # Skip already downloaded

    url = f"https://www.dawateislami.net/quran/surah-{surah_name}/ayat-{ayah_num}"

    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
    except Exception as e:
        print(f"Failed to fetch Surah {surah_num} Ayah {ayah_num}: {e}")
        return

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(r.text, "html.parser")
    span = soup.select_one("span.variable_font")

    if not span:
        print(f"Text not found Surah {surah_num} Ayah {ayah_num}")
        return

    text = span.text.strip()

    html_content = f"""
    <html>
    <head>
    <meta charset="UTF-8" />
    <title>Surah {surah_num} Ayah {ayah_num}</title>
    <style>
      body {{
        font-family: 'Al Qalam Quran Majeed Web2_D', serif;
        direction: rtl;
        font-size: 24px;
        line-height: 2;
        padding: 20px;
      }}
    </style>
    </head>
    <body>
      <p>{text}</p>
    </body>
    </html>
    """

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html_content)

def main():
    total = sum(ayahs_per_surah)
    print(f"Total ayahs to download: {total}")
    for surah_num, max_ayah in enumerate(ayahs_per_surah, start=1):
        print(f"Downloading Surah {surah_num} ({surah_names[surah_num-1]}) with {max_ayah} ayahs")
        for ayah_num in range(1, max_ayah + 1):
            fetch_and_save_ayah(surah_num, ayah_num)

if __name__ == "__main__":
    main()
