import os
import requests
from bs4 import BeautifulSoup
from tqdm import tqdm

# Folder to save downloaded ayah HTML files
DOWNLOAD_FOLDER = os.path.expanduser('~/Downloads/Quran_Arabic_Text')
os.makedirs(DOWNLOAD_FOLDER, exist_ok=True)

# List of surah transliterated names as used in dawateislami.net URLs, all 114 surahs
surah_names = [
    "al-fatihah", "al-baqarah", "al-imran", "an-nisa", "al-maidah", "al-anam", "al-araf",
    "al-anfal", "at-tawbah", "yunus", "hud", "yusuf", "ar-rad", "ibrahim", "al-hijr",
    "an-nahl", "al-isra", "al-kahf", "maryam", "taha", "al-anbiya", "al-hajj", "al-muminun",
    "an-nur", "al-furqan", "ash-shuara", "an-naml", "al-qasas", "al-ankabut", "ar-rum",
    "luqman", "as-sajda", "al-ahzab", "saba", "fatir", "ya-sin", "as-saffat", "sad",
    "az-zumar", "ghafir", "fussilat", "ash-shura", "az-zukhruf", "ad-dukhan", "al-jathiya",
    "al-ahqaf", "muhammad", "al-fath", "al-hujurat", "qaf", "adh-dhariyat", "at-tur",
    "an-najm", "al-qamar", "ar-rahman", "al-waqi'a", "al-hadid", "al-mujadila", "al-hashr",
    "al-mumtahina", "as-saff", "al-jumua", "al-munafiqun", "at-taghabun", "at-talaq",
    "at-tahrim", "al-mulk", "al-qalam", "al-haqqa", "al-maarij", "nuh", "al-jinn",
    "al-muzzammil", "al-muddaththir", "al-qiyama", "al-insan", "al-mursalat", "an-naba",
    "an-naziat", "abasa", "at-takwir", "al-infitar", "al-mutaffifin", "al-inshiqaq",
    "al-burooj", "at-tariq", "al-ala", "al-ghashiya", "al-fajr", "al-balad", "ash-shams",
    "al-lail", "ad-duha", "ash-sharh", "at-tin", "al-alaq", "al-qadr", "al-bayyina",
    "az-zalzalah", "al-adiyat", "al-qaria", "at-takathur", "al-asr", "al-humaza",
    "al-fil", "quraysh", "al-maun", "al-kauthar", "al-kafirun", "an-nasr", "al-masad",
    "al-ikhlas", "al-falaq", "an-nas"
]

# Number of ayahs in each surah exactly as per Quran
ayahs_per_surah = [
    7, 286, 200, 176, 120, 165, 206, 75, 129, 109,
    123, 111, 43, 52, 99, 128, 111, 110, 98, 135,
    112, 78, 118, 64, 77, 227, 93, 88, 69, 60,
    34, 30, 73, 54, 45, 83, 182, 88, 75, 85,
    54, 53, 89, 59, 37, 35, 38, 29, 18, 45,
    60, 49, 62, 55, 78, 96, 29, 22, 24, 13,
    14, 11, 11, 18, 12, 12, 30, 52, 52, 44,
    28, 28, 20, 56, 40, 31, 50, 40, 46, 42,
    29, 19, 36, 25, 22, 17, 19, 26, 30, 20,
    15, 21, 11, 8, 8, 19, 5, 8, 8, 11,
    11, 8, 3, 9, 5, 4, 7, 3, 6, 3,
    5, 4, 5, 6
]

def fetch_and_save_ayah(surah_num, ayah_num):
    surah_name = surah_names[surah_num - 1]
    filename = f"{str(surah_num).zfill(3)}{str(ayah_num).zfill(3)}.html"
    filepath = os.path.join(DOWNLOAD_FOLDER, filename)

    if os.path.exists(filepath):
        return  # Skip already downloaded

    url = f"https://www.dawateislami.net/quran/surah-{surah_name}/ayat-{ayah_num}"

    try:
        r = requests.get(url, timeout=30)
        r.raise_for_status()
    except Exception as e:
        print(f"Failed to fetch Surah {surah_num} Ayah {ayah_num}: {e}")
        return

    from bs4 import BeautifulSoup
    soup = BeautifulSoup(r.text, "html.parser")
    span = soup.select_one("span.variable_font")

    if not span:
        print(f"Text not found Surah {surah_num} Ayah {ayah_num}")
        return

    text = span.text.strip()

    html_content = f"""
    <html>
    <head>
    <meta charset="UTF-8" />
    <title>Surah {surah_num} Ayah {ayah_num}</title>
    <style>
      body {{
        font-family: 'Al Qalam Quran Majeed Web2_D', serif;
        direction: rtl;
        font-size: 24px;
        line-height: 2;
        padding: 20px;
      }}
    </style>
    </head>
    <body>
      <p>{text}</p>
    </body>
    </html>
    """

    with open(filepath, "w", encoding="utf-8") as f:
        f.write(html_content)

def main():
    total = sum(ayahs_per_surah)
    print(f"Total ayahs to download: {total}")
    for surah_num, max_ayah in enumerate(ayahs_per_surah, start=1):
        print(f"Downloading Surah {surah_num} ({surah_names[surah_num-1]}) with {max_ayah} ayahs")
        for ayah_num in range(1, max_ayah + 1):
            fetch_and_save_ayah(surah_num, ayah_num)

if __name__ == "__main__":
    main()
