/* UTILS */
const $ = (sel, root=document) => root.querySelector(sel);
const $$ = (sel, root=document) => Array.from(root.querySelectorAll(sel));
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

/* CONFIGURATION */
const RECITERS = [
{ id: "mishary_rashid_al_afasy", name: "Sheikh Mishary Rashid Al-Afasy", folder: "Mishary Rashid Alafasy" },
{ id: "nasser_al_qatami", name: "Sheikh Nasser Al Qatami", folder: "Nasser Al Qatami" },
{ id: "al-Hudhaifi", name: "Sheikh Ali Al Hudhaifi (Alhozifi)", folder: "Sheikh Ali Al Hudhaifi (Alhozifi)" },
{ id: "aziz_alili", name: "Sheikh Aziz Alili", folder: "Aziz Alili" },
{ id: "yasser_al_dosari", name: "Sheikh Yasser Al-Dosari", folder: "Yasser Al-Dosari" },
{ id: "muhammad_siddiq_al_minshawi", name: "Sheikh Muhammad Siddiq Al-Minshawi", folder: "Muhammad Siddiq al-Minshawi Murattal" },
{ id: "mohammad_mahmud_al_tablawi", name: "Sheikh Mohammad Mahmud Al Tablawi", folder: "Mohammad Al Tablaway" },
{ id: "ayman_bin_rushdi_swayd", name: "Sheikh Ayman bin Rushdi Swayd", folder: "Ayman Sowaid" },
{ id: "ibrahim_ibn_al_akhdar_al_kayim", name: "Sheikh Ibrahim Ibn Al Akhdar Al Kayim", folder: "Ibrahim Akhdar" },
{ id: "mahmoud_khalil_al_hussary", name: "Sheikh Mahmoud Khalil Al-Hussary", folder: "Mahmoud Khalil Al-Husary Mujawwad" },
{ id: "saad_ghamdi", name: "Sheikh Saad Al Ghamdi", folder: "Saad Al Ghamdi" },
{ id: "Muhsin_al_Qasim", name: "Sheikh Abdul Muhsin al Qasim", folder: "Abdul Muhsin al Qasim" },
{ id: "shahriar_parhizkar", name: "Sheikh Shahriar Parhizkar", folder: "Shahriar Parhizkar" },
{ id: "abdullah_awad_al_juhany", name: "Sheikh Abdullah Awad Al-Juhany", folder: "Abdullah Awad Al Juhani" },
];


const SURAH_LIST = [
  { number:1,name:"Al-Fatihah",ayahs:7 },
  { number:2,name:"Al-Baqarah",ayahs:286 },
  { number:3,name:"Aal-E-Imran",ayahs:200 },
  { number:4,name:"An-Nisa",ayahs:176 },
  { number:5,name:"Al-Ma'idah",ayahs:120 },
  { number:6,name:"Al-An'am",ayahs:165 },
  { number:7,name:"Al-A'raf",ayahs:206 },
  { number:8,name:"Al-Anfal",ayahs:75 },
  { number:9,name:"At-Tawbah",ayahs:129 },
  { number:10,name:"Yunus",ayahs:109 },
  { number:11,name:"Hud",ayahs:123 },
  { number:12,name:"Yusuf",ayahs:111 },
  { number:13,name:"Ar-Ra'd",ayahs:43 },
  { number:14,name:"Ibrahim",ayahs:52 },
  { number:15,name:"Al-Hijr",ayahs:99 },
  { number:16,name:"An-Nahl",ayahs:128 },
  { number:17,name:"Al-Isra",ayahs:111 },
  { number:18,name:"Al-Kahf",ayahs:110 },
  { number:19,name:"Maryam",ayahs:98 },
  { number:20,name:"Ta-Ha",ayahs:135 },
  { number:21,name:"Al-Anbiya",ayahs:112 },
  { number:22,name:"Al-Hajj",ayahs:78 },
  { number:23,name:"Al-Mu'minun",ayahs:118 },
  { number:24,name:"An-Nur",ayahs:64 },
  { number:25,name:"Al-Furqan",ayahs:77 },
  { number:26,name:"Ash-Shu'ara",ayahs:227 },
  { number:27,name:"An-Naml",ayahs:93 },
  { number:28,name:"Al-Qasas",ayahs:88 },
  { number:29,name:"Al-Ankabut",ayahs:69 },
  { number:30,name:"Ar-Rum",ayahs:60 },
  { number:31,name:"Luqman",ayahs:34 },
  { number:32,name:"As-Sajdah",ayahs:30 },
  { number:33,name:"Al-Ahzab",ayahs:73 },
  { number:34,name:"Saba",ayahs:54 },
  { number:35,name:"Fatir",ayahs:45 },
  { number:36,name:"Ya-Sin",ayahs:83 },
  { number:37,name:"As-Saffat",ayahs:182 },
  { number:38,name:"Sad",ayahs:88 },
  { number:39,name:"Az-Zumar",ayahs:75 },
  { number:40,name:"Ghafir",ayahs:85 },
  { number:41,name:"Fussilat",ayahs:54 },
  { number:42,name:"Ash-Shura",ayahs:53 },
  { number:43,name:"Az-Zukhruf",ayahs:89 },
  { number:44,name:"Ad-Dukhan",ayahs:59 },
  { number:45,name:"Al-Jathiyah",ayahs:37 },
  { number:46,name:"Al-Ahqaf",ayahs:35 },
  { number:47,name:"Muhammad",ayahs:38 },
  { number:48,name:"Al-Fath",ayahs:29 },
  { number:49,name:"Al-Hujurat",ayahs:18 },
  { number:50,name:"Qaf",ayahs:45 },
  { number:51,name:"Adh-Dhariyat",ayahs:60 },
  { number:52,name:"At-Tur",ayahs:49 },
  { number:53,name:"An-Najm",ayahs:62 },
  { number:54,name:"Al-Qamar",ayahs:55 },
  { number:55,name:"Ar-Rahman",ayahs:78 },
  { number:56,name:"Al-Waqi'ah",ayahs:96 },
  { number:57,name:"Al-Hadid",ayahs:29 },
  { number:58,name:"Al-Mujadila",ayahs:22 },
  { number:59,name:"Al-Hashr",ayahs:24 },
  { number:60,name:"Al-Mumtahanah",ayahs:13 },
  { number:61,name:"As-Saff",ayahs:14 },
  { number:62,name:"Al-Jumu'ah",ayahs:11 },
  { number:63,name:"Al-Munafiqun",ayahs:11 },
  { number:64,name:"At-Taghabun",ayahs:18 },
  { number:65,name:"At-Talaq",ayahs:12 },
  { number:66,name:"At-Tahrim",ayahs:12 },
  { number:67,name:"Al-Mulk",ayahs:30 },
  { number:68,name:"Al-Qalam",ayahs:52 },
  { number:69,name:"Al-Haqqah",ayahs:52 },
  { number:70,name:"Al-Ma'arij",ayahs:44 },
  { number:71,name:"Nuh",ayahs:28 },
  { number:72,name:"Al-Jinn",ayahs:28 },
  { number:73,name:"Al-Muzzammil",ayahs:20 },
  { number:74,name:"Al-Muddaththir",ayahs:56 },
  { number:75,name:"Al-Qiyamah",ayahs:40 },
  { number:76,name:"Al-Insan",ayahs:31 },
  { number:77,name:"Al-Mursalat",ayahs:50 },
  { number:78,name:"An-Naba",ayahs:40 },
  { number:79,name:"An-Nazi'at",ayahs:46 },
  { number:80,name:"Abasa",ayahs:42 },
  { number:81,name:"At-Takwir",ayahs:29 },
  { number:82,name:"Al-Infitar",ayahs:19 },
  { number:83,name:"Al-Mutaffifin",ayahs:36 },
  { number:84,name:"Al-Inshiqaq",ayahs:25 },
  { number:85,name:"Al-Buruj",ayahs:22 },
  { number:86,name:"At-Tariq",ayahs:17 },
  { number:87,name:"Al-A'la",ayahs:19 },
  { number:88,name:"Al-Ghashiyah",ayahs:26 },
  { number:89,name:"Al-Fajr",ayahs:30 },
  { number:90,name:"Al-Balad",ayahs:20 },
  { number:91,name:"Ash-Shams",ayahs:15 },
  { number:92,name:"Al-Layl",ayahs:21 },
  { number:93,name:"Ad-Duha",ayahs:11 },
  { number:94,name:"Ash-Sharh",ayahs:8 },
  { number:95,name:"At-Tin",ayahs:8 },
  { number:96,name:"Al-Alaq",ayahs:19 },
  { number:97,name:"Al-Qadr",ayahs:5 },
  { number:98,name:"Al-Bayyina",ayahs:8 },
  { number:99,name:"Az-Zalzalah",ayahs:8 },
  { number:100,name:"Al-Adiyat",ayahs:11 },
  { number:101,name:"Al-Qari'ah",ayahs:11 },
  { number:102,name:"At-Takathur",ayahs:8 },
  { number:103,name:"Al-Asr",ayahs:3 },
  { number:104,name:"Al-Humazah",ayahs:9 },
  { number:105,name:"Al-Fil",ayahs:5 },
  { number:106,name:"Quraysh",ayahs:4 },
  { number:107,name:"Al-Ma'un",ayahs:7 },
  { number:108,name:"Al-Kawthar",ayahs:3 },
  { number:109,name:"Al-Kafirun",ayahs:6 },
  { number:110,name:"An-Nasr",ayahs:3 },
  { number:111,name:"Al-Masad",ayahs:5 },
  { number:112,name:"Al-Ikhlas",ayahs:4 },
  { number:113,name:"Al-Falaq",ayahs:5 },
  { number:114,name:"An-Nas",ayahs:6 }
];

/* DOM Elements */
const surahSelect = $("#surahSelect");
const reciterListDiv = $("#reciterList");
const currentReciterName = $("#currentReciterName");
const currentSurahName = $("#currentSurahName");
const currentAyahNumber = $("#currentAyahNumber");
const progressText = $("#progressText");
const hiddenAudio = $("#hiddenAudio");
const btnPlayPause = $("#playPause");
const btnPrevSurah = $("#prevSurah");
const btnNextSurah = $("#nextSurah");
const btnPrevAyah = $("#prevAyah");
const btnNextAyah = $("#nextAyah");
const btnRepeatAyah = $("#repeatAyah");
const btnCycleReciters = $("#cycleReciters");
const chkNextSurah = $("#chkNextSurah");

/* State */
const state = {
  currentReciter: RECITERS[0].id,
  currentSurah: 1,
  currentAyah: 1,
  isPlaying: false,
  repeatAyah: false,
  cycleReciters: false,
  currentAudioSrc: ""
};

/* Save state to LocalStorage */
function saveStateToLocalStorage() {
  const saveObj = {
    currentReciter: state.currentReciter,
    currentSurah: state.currentSurah,
    currentAyah: state.currentAyah,
    repeatAyah: state.repeatAyah,
    cycleReciters: state.cycleReciters,
    chkNextSurah: chkNextSurah.checked
  };
  localStorage.setItem("quranPlayerState", JSON.stringify(saveObj));
}

/* Load state from LocalStorage */
function loadStateFromLocalStorage() {
  const saved = localStorage.getItem("quranPlayerState");
  if (!saved) return;
  try {
    const obj = JSON.parse(saved);
    if (obj.currentReciter && RECITERS.some(r => r.id === obj.currentReciter))
      state.currentReciter = obj.currentReciter;
    if (obj.currentSurah) state.currentSurah = obj.currentSurah;
    if (obj.currentAyah) state.currentAyah = obj.currentAyah;
    if (typeof obj.repeatAyah === "boolean") state.repeatAyah = obj.repeatAyah;
    if (typeof obj.cycleReciters === "boolean") state.cycleReciters = obj.cycleReciters;
    if (typeof obj.chkNextSurah === "boolean")
      chkNextSurah.checked = obj.chkNextSurah;
  } catch {}
}

/* Initialization */
document.addEventListener("DOMContentLoaded", () => {
  renderSurahOptions();
  renderReciters();
  loadStateFromLocalStorage();

  // Show/hide ayah selection according to saved toggle or default hidden
  const toggleAyahSelectCheckbox = document.getElementById("toggleAyahSelect");
  if (toggleAyahSelectCheckbox) {
    progressText.style.display = toggleAyahSelectCheckbox.checked ? "block" : "none";
    toggleAyahSelectCheckbox.addEventListener("change", () => {
      progressText.style.display = toggleAyahSelectCheckbox.checked ? "block" : "none";
    });
  } else {
    progressText.style.display = "none";
  }

  setSurah(state.currentSurah, state.currentAyah, false);
  setActiveReciter(state.currentReciter, false);
  updateRepeatCycleButtons();
  wireEvents();
  updateNowPlayingUI();
  updateProgressUI();
});

/* Render Surah Options */
function renderSurahOptions() {
  surahSelect.innerHTML = "";
  SURAH_LIST.forEach(surah => {
    const opt = document.createElement("option");
    opt.value = surah.number;
    opt.textContent = `${surah.number}. ${surah.name}`;
    surahSelect.appendChild(opt);
  });
  surahSelect.value = state.currentSurah;
}

/* Render Reciters */
function renderReciters() {
  reciterListDiv.innerHTML = "";
  RECITERS.forEach(r => {
    const row = document.createElement("div");
    row.className = "reciterRow";
    row.dataset.reciter = r.id;

    const nameDiv = document.createElement("div");
    nameDiv.className = "name";
    nameDiv.textContent = r.name;
    nameDiv.style.cursor = "pointer";
    nameDiv.title = `Click to play ${r.name}`;
    nameDiv.addEventListener("click", () => {
      setActiveReciter(r.id, true);
    });

    const playBtn = document.createElement("button");
    playBtn.className = "btn";
    playBtn.textContent = "Play";
    playBtn.title = `Make ${r.name} active and play`;
    playBtn.addEventListener("click", () => {
      setActiveReciter(r.id, true);
    });

    row.appendChild(nameDiv);
    row.appendChild(playBtn);
    reciterListDiv.appendChild(row);
  });
  highlightActiveReciter();
}

/* Highlight Active Reciter */
function highlightActiveReciter() {
  $$(".reciterRow").forEach(row => {
    row.classList.toggle("active", row.dataset.reciter === state.currentReciter);
  });
}

/* Set Active Reciter */
function setActiveReciter(reciterId, playNow = false) {
  if (!RECITERS.some(r => r.id === reciterId)) return;
  state.currentReciter = reciterId;
  localStorage.setItem("quran:lastReciter", reciterId);
  highlightActiveReciter();
  updateNowPlayingUI();
  saveStateToLocalStorage();
  if (playNow) prepareAndPlay();
}

/* Get Surah Metadata */
function getSurahMeta(n) {
  return SURAH_LIST.find(s => s.number === Number(n)) || SURAH_LIST[0];
}

/* Set Surah and Ayah */
function setSurah(surahNumber, ayahNumber = 1, autoplay = true) {
  const meta = getSurahMeta(surahNumber);
  state.currentSurah = meta.number;
  state.currentAyah = clamp(ayahNumber, 1, meta.ayahs);

  surahSelect.value = String(meta.number);
  updateNowPlayingUI();
  updateProgressUI();
  saveStateToLocalStorage();
  if (autoplay) prepareAndPlay();
}

/* Get Audio Source */
function audioSrcFor(surah, ayah, reciterId) {
  const file = `${String(surah).padStart(3, "0")}${String(ayah).padStart(3, "0")}.mp3`;
  const folder = RECITERS.find(r => r.id === reciterId)?.folder || RECITERS[0].folder;
  return `audio/${folder}/${file}`;
}

/* Prepare and Play Audio */
function prepareAndPlay() {
  const meta = getSurahMeta(state.currentSurah);
  state.currentAyah = clamp(state.currentAyah, 1, meta.ayahs);
  const src = audioSrcFor(state.currentSurah, state.currentAyah, state.currentReciter);

  if (src !== state.currentAudioSrc) {
    hiddenAudio.src = src;
    state.currentAudioSrc = src;
    hiddenAudio.currentTime = 0;
  }

  hiddenAudio.play().then(() => {
    state.isPlaying = true;
    btnPlayPause.textContent = "⏸ Pause";
    btnPlayPause.classList.add("playing");
    updateNowPlayingUI();
    updateProgressUI();
  }).catch(err => {
    console.warn("Playback error:", err);
    state.isPlaying = false;
    btnPlayPause.textContent = "▶ Play";
    btnPlayPause.classList.remove("playing");
  });
  saveStateToLocalStorage();
}

/* Stop Playback */
function stopPlayback() {
  hiddenAudio.pause();
  hiddenAudio.currentTime = 0;
  state.isPlaying = false;
  btnPlayPause.textContent = "▶ Play";
  btnPlayPause.classList.remove("playing");
  updateProgressUI();
  saveStateToLocalStorage();
}

/* On Audio Ended */
function onAudioEnded() {
  if (state.repeatAyah) {
    prepareAndPlay();
    return;
  }
  if (state.cycleReciters) {
    const idx = RECITERS.findIndex(r => r.id === state.currentReciter);
    const nextIdx = (idx + 1) % RECITERS.length;
    setActiveReciter(RECITERS[nextIdx].id);
    prepareAndPlay();
    return;
  }
  const meta = getSurahMeta(state.currentSurah);
  if (state.currentAyah < meta.ayahs) {
    state.currentAyah++;
    prepareAndPlay();
    return;
  }
  if (chkNextSurah.checked && state.currentSurah < 114) {
    setSurah(state.currentSurah + 1, 1, true);
    return;
  }
  stopPlayback();
}

/* Player Controls */
function togglePlayPause() {
  if (state.isPlaying) {
    hiddenAudio.pause();
    state.isPlaying = false;
    btnPlayPause.textContent = "▶ Play";
    btnPlayPause.classList.remove("playing");
  } else {
    prepareAndPlay();
  }
}

function prevAyahAction() {
  if (state.currentAyah > 1) {
    state.currentAyah--;
    prepareAndPlay();
  } else if (state.currentSurah > 1) {
    const prevSurah = getSurahMeta(state.currentSurah - 1);
    setSurah(prevSurah.number, prevSurah.ayahs, true);
  }
}

function nextAyahAction() {
  const meta = getSurahMeta(state.currentSurah);
  if (state.currentAyah < meta.ayahs) {
    state.currentAyah++;
    prepareAndPlay();
  } else if (chkNextSurah.checked && state.currentSurah < 114) {
    setSurah(state.currentSurah + 1, 1, true);
  } else {
    stopPlayback();
  }
}

function prevSurahAction() {
  if (state.currentSurah > 1) {
    setSurah(state.currentSurah - 1, 1, true);
  }
}

function nextSurahAction() {
  if (state.currentSurah < 114) {
    setSurah(state.currentSurah + 1, 1, true);
  }
}

/* Update Now Playing UI */
function updateNowPlayingUI() {
  const reciter = RECITERS.find(r => r.id === state.currentReciter) || RECITERS[0];
  const surah = getSurahMeta(state.currentSurah);
  currentReciterName.textContent = reciter.name;
  currentSurahName.textContent = `${surah.number}. ${surah.name}`;
  currentAyahNumber.textContent = state.currentAyah;
  updateProgressUI();
}

/* Update Progress UI with ayah selector */
function updateProgressUI() {
  const meta = getSurahMeta(state.currentSurah);
  const total = meta.ayahs;
  const current = state.currentAyah;

  progressText.innerHTML = "";

  const summary = document.createElement("div");
  summary.textContent = `Ayah ${current} / ${total}`;
  summary.className = "ayahSummary";
  progressText.appendChild(summary);

  for(let i=1; i<=total; i++) {
    const span = document.createElement("span");
    span.className = "ayahSegment";
    if(i === current) span.classList.add("activeAyah");
    span.textContent = i;
    span.title = `Go to ayah ${i}`;
    span.style.cursor = "pointer";
    span.addEventListener("click", () => {
      state.currentAyah = i;
      prepareAndPlay();
    });
    progressText.appendChild(span);
  }

  saveStateToLocalStorage();
}

/* Wire all events */
function wireEvents() {
  surahSelect.addEventListener("change", e => {
    const n = parseInt(e.target.value, 10);
    if(Number.isFinite(n)) setSurah(n, 1, true);
  });

  btnPlayPause.addEventListener("click", togglePlayPause);
  btnPrevAyah.addEventListener("click", prevAyahAction);
  btnNextAyah.addEventListener("click", nextAyahAction);
  btnPrevSurah.addEventListener("click", prevSurahAction);
  btnNextSurah.addEventListener("click", nextSurahAction);

  btnRepeatAyah.addEventListener("click", () => {
    state.repeatAyah = !state.repeatAyah;
    if(state.repeatAyah) state.cycleReciters = false;
    updateRepeatCycleButtons();
    saveStateToLocalStorage();
  });

  btnCycleReciters.addEventListener("click", () => {
    state.cycleReciters = !state.cycleReciters;
    if(state.cycleReciters) state.repeatAyah = false;
    updateRepeatCycleButtons();
    saveStateToLocalStorage();
  });

  hiddenAudio.addEventListener("ended", onAudioEnded);
  hiddenAudio.addEventListener("error", e => {
    console.warn("Audio error:", e);
    const meta = getSurahMeta(state.currentSurah);
    if(state.currentAyah < meta.ayahs) {
      state.currentAyah++;
      prepareAndPlay();
    } else {
      stopPlayback();
    }
  });

  chkNextSurah.addEventListener("change", () => {
    saveStateToLocalStorage();
  });
}

/* Update Repeat and Cycle Buttons UI */
function updateRepeatCycleButtons() {
  btnRepeatAyah.classList.toggle("active", state.repeatAyah);
  btnCycleReciters.classList.toggle("active", state.cycleReciters);
}

/* Restore last reciter (if any) */
function restoreLastReciter() {
  const last = localStorage.getItem("quran:lastReciter");
  if(last && RECITERS.some(r => r.id === last)) {
    state.currentReciter = last;
  } else {
    localStorage.setItem("quran:lastReciter", state.currentReciter);
  }
  highlightActiveReciter();
}

/* Debug Exports */
window.quranPlayer = {
  state,
  setSurah,
  prepareAndPlay,
  stopPlayback
};

// --- Quran Text Integration ---
const toggleTextCheckbox = document.getElementById("toggleText");
const quranTextSection = document.getElementById("quranText");
// const quranTextContent = document.getElementById("quranTextContent");
let scrollMode = "autoSync"; // default




const textSizeSlider = document.getElementById("textSizeSlider");
const textSizeValue = document.getElementById("textSizeValue");
const quranTextContent = document.getElementById("quranTextContent");

if (textSizeSlider) {
  textSizeSlider.addEventListener("input", () => {
    const size = textSizeSlider.value + "px";
    quranTextContent.style.fontSize = size;
    textSizeValue.textContent = size;
    localStorage.setItem("quranTextSize", size); // save user choice
  });

  // Restore saved text size
  const savedSize = localStorage.getItem("quranTextSize");
  if (savedSize) {
    quranTextContent.style.fontSize = savedSize;
    textSizeSlider.value = parseInt(savedSize);
    textSizeValue.textContent = savedSize;
  }
}






// Show/hide Quran text
if (toggleTextCheckbox) {
  toggleTextCheckbox.addEventListener("change", () => {
    quranTextSection.style.display = toggleTextCheckbox.checked ? "block" : "none";
  });
}

// Handle scroll mode selection
$$("input[name='scrollMode']").forEach(radio => {
  radio.addEventListener("change", e => {
    scrollMode = e.target.value;
  });
});

// Highlight and sync Quran text with audio
function pad3(n) { return String(n).padStart(3, "0"); }

function highlightCurrentAyahText() {
  $$("#quranTextContent .ayah").forEach(el => el.classList.remove("activeAyahText"));

  const surahStr = pad3(state.currentSurah);
  const ayahStr = pad3(state.currentAyah);
  const selector = `#quranTextContent .ayah[data-surah='${surahStr}'][data-ayah='${ayahStr}']`;
  
  const currentAyahEl = document.querySelector(selector);
  if (currentAyahEl) {
    currentAyahEl.classList.add("activeAyahText");
    if (scrollMode === "autoScroll" || scrollMode === "autoSync") {
      currentAyahEl.scrollIntoView({ behavior: "smooth", block: "center" });
    }
  }
}


// Inject CSS highlight
const style = document.createElement("style");
style.textContent = `
  .activeAyahText {
    background: #007bff;
    color: white;
    padding: 2px 4px;
    border-radius: 3px;
  }
`;
document.head.appendChild(style);

// Patch updateNowPlayingUI to also highlight text
const _updateNowPlayingUI = updateNowPlayingUI;
updateNowPlayingUI = function() {
  _updateNowPlayingUI();
  highlightCurrentAyahText();
};


