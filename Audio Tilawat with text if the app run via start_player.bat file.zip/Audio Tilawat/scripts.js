/* =========================================================
   Local Quran Audio Player + PDF.js sync — scripts.js
   =========================================================
   - Keeps your audio features (surah/reciter, loop, auto-next, repeat)
   - Adds PDF "Read" mode:
       * Header hides to free space
       * PDF centered (not stretched) with room for future side panels
       * Close button
       * Sync once to current audio position
       * Auto-scroll with audio (toggle)
   - Sticky bottom control bar that auto-hides gently
   ========================================================= */

/* ---------- Elements ---------- */
const surahDropdown   = document.getElementById("surahDropdown");
const reciterDropdown = document.getElementById("reciterDropdown");
const surahSearch     = document.getElementById("surahSearch");
const reciterSearch   = document.getElementById("reciterSearch");
const surahDataList   = document.getElementById("surahListDatalist");
const reciterDataList = document.getElementById("reciterListDatalist");

const playBtn    = document.getElementById("playBtn");
const pauseBtn   = document.getElementById("pauseBtn");
const stopBtn    = document.getElementById("stopBtn");
const nextBtn    = document.getElementById("nextBtn");
const prevBtn    = document.getElementById("prevBtn");
const forwardBtn = document.getElementById("forwardBtn");
const rewindBtn  = document.getElementById("rewindBtn");
const repeat5Btn = document.getElementById("repeat5Btn");

const loopToggle     = document.getElementById("loopToggle");
const autoNextToggle = document.getElementById("autoNextToggle");

const progressBar     = document.getElementById("progressBar");
const progressDisplay = document.getElementById("progressDisplay");
const currentTimeEl   = document.getElementById("currentTime");
const totalTimeEl     = document.getElementById("totalTime");

const openPdfBtn  = document.getElementById("openPdfBtn");
const pdfStage    = document.getElementById("pdfStage");
const pdfScroll   = document.getElementById("pdfScroll");
const closePdfBtn = document.getElementById("closePdfBtn");
const autoSyncToggle = document.getElementById("autoSyncToggle");
const syncOnceBtn = document.getElementById("syncOnceBtn");

const controlBar  = document.getElementById("controlBar");
const barPrev     = document.getElementById("barPrev");
const barRew      = document.getElementById("barRew");
const barPlay     = document.getElementById("barPlay");
const barPause    = document.getElementById("barPause");
const barStop     = document.getElementById("barStop");
const barFwd      = document.getElementById("barFwd");
const barNext     = document.getElementById("barNext");
const barRepeat   = document.getElementById("barRepeat");
const barProgress = document.getElementById("barProgress");
const barTime     = document.getElementById("barTime");
const barRead     = document.getElementById("barRead");

/* ---------- Audio State ---------- */
let audio = new Audio();

let currentSurahIndex = 0;   // 0..115 (114 & 115 are duas)
let currentReciterIndex = 0; // 0..reciters.length-1
let currentPercentage = 0;   // for reciter switch

// Repeat seconds (change here to 10 if you want default 10s)
let repeatSeconds = 10;
let repeatActive = false;
let repeatStart = 0;
let repeatEnd = 0;

/* ---------- Data ---------- */
const reciters = [
  { name: "Shaikh Ayman Suwayd", folder: "Shaikh Ayman Suwayd" },
  { name: "Mishary Rashid Alafasy", folder: "Mishary Rashid Alafasy" },

  { name: "Mustafa Raad Al Azzawi", folder: "Mustafa Raad Al Azzawi" },
  { name: "Qari Syed Sadaqat Ali", folder: "Qari Syed Sadaqat Ali" },
  { name: "Nasser Al Qatami", folder: "Nasser Al Qatami" },
  { name: "Mahmoud Khalil Al-Hussary", folder: "Mahmoud Khalil Al-Hussary" },
  { name: "Hafez Ishak Danish", folder: "Hafez Ishak Danish" },


  { name: "Abdualhaleem Hussain", folder: "Abdualhaleem-Hussain" },
  { name: "Abdul Rachid Soufi", folder: "Abdul_Rachid_Soufi" }

];

const surahList = [
  "1 Al-Fatiha","2 Al-Baqarah","3 Aal-E-Imran","4 An-Nisa","5 Al-Maidah",
  "6 Al-An'am","7 Al-A'raf","8 Al-Anfal","9 At-Tawbah","10 Yunus",
  "11 Hud","12 Yusuf","13 Ar-Ra'd","14 Ibrahim","15 Al-Hijr",
  "16 An-Nahl","17 Al-Isra","18 Al-Kahf","19 Maryam","20 Ta-Ha",
  "21 Al-Anbiya","22 Al-Hajj","23 Al-Mu’minun","24 An-Nur","25 Al-Furqan",
  "26 Ash-Shu'ara","27 An-Naml","28 Al-Qasas","29 Al-Ankabut","30 Ar-Rum",
  "31 Luqman","32 As-Sajdah","33 Al-Ahzab","34 Saba","35 Fatir",
  "36 Ya-Sin","37 As-Saffat","38 Sad","39 Az-Zumar","40 Ghafir",
  "41 Fussilat","42 Ash-Shura","43 Az-Zukhruf","44 Ad-Dukhan","45 Al-Jathiyah",
  "46 Al-Ahqaf","47 Muhammad","48 Al-Fath","49 Al-Hujurat","50 Qaf",
  "51 Adh-Dhariyat","52 At-Tur","53 An-Najm","54 Al-Qamar","55 Ar-Rahman",
  "56 Al-Waqi'ah","57 Al-Hadid","58 Al-Mujadila","59 Al-Hashr","60 Al-Mumtahanah",
  "61 As-Saff","62 Al-Jumu'ah","63 Al-Munafiqun","64 At-Taghabun","65 At-Talaq",
  "66 At-Tahrim","67 Al-Mulk","68 Al-Qalam","69 Al-Haqqah","70 Al-Ma'arij",
  "71 Nuh","72 Al-Jinn","73 Al-Muzzammil","74 Al-Muddathir","75 Al-Qiyamah",
  "76 Al-Insan","77 Al-Mursalat","78 An-Naba","79 An-Nazi'at","80 Abasa",
  "81 At-Takwir","82 Al-Infitar","83 Al-Mutaffifin","84 Al-Inshiqaq","85 Al-Buruj",
  "86 At-Tariq","87 Al-A'la","88 Al-Ghashiyah","89 Al-Fajr","90 Al-Balad",
  "91 Ash-Shams","92 Al-Lail","93 Ad-Duhaa","94 Ash-Sharh","95 At-Tin",
  "96 Al-Alaq","97 Al-Qadr","98 Al-Bayyinah","99 Az-Zalzalah","100 Al-Adiyat",
  "101 Al-Qari'ah","102 At-Takathur","103 Al-Asr","104 Al-Humazah","105 Al-Fil",
  "106 Quraish","107 Al-Ma'un","108 Al-Kawthar","109 Al-Kafiroon","110 An-Nasr",
  "111 Al-Masad","112 Al-Ikhlas","113 Al-Falaq","114 An-Nas",
  "End of Quran Dua 1","End of Quran Dua 2"
];

/* ---------- UI populate ---------- */
function populateSurahDropdowns() {
  surahDropdown.innerHTML = "";
  surahDataList.innerHTML = "";
  surahList.forEach((label, i) => {
    const opt = document.createElement("option");
    opt.value = i; opt.textContent = label;
    surahDropdown.appendChild(opt);

    const d = document.createElement("option");
    d.value = label;
    surahDataList.appendChild(d);
  });
}
function populateReciterDropdowns() {
  reciterDropdown.innerHTML = "";
  reciterDataList.innerHTML = "";
  reciters.forEach((r, i) => {
    const opt = document.createElement("option");
    opt.value = i; opt.textContent = r.name;
    reciterDropdown.appendChild(opt);

    const d = document.createElement("option");
    d.value = r.name;
    reciterDataList.appendChild(d);
  });
}

/* ---------- Helpers ---------- */
function pad3(n){ return String(n).padStart(3,"0"); }
function formatTime(sec){ if(!isFinite(sec)||sec<0)sec=0; const m=Math.floor(sec/60), s=Math.floor(sec%60); return `${String(m).padStart(2,"0")}:${String(s).padStart(2,"0")}`; }
function isDuaIndex(i){ return i>=114; }
function buildAudioSrc(){
  if(isDuaIndex(currentSurahIndex)){
    const duaFile = currentSurahIndex===114 ? "Dua1.mp3" : "Dua2.mp3";
    return `End of Quran Dua/${duaFile}`;
  } else {
    const folder = reciters[currentReciterIndex].folder;
    return `${folder}/${pad3(currentSurahIndex+1)}.mp3`;
  }
}
function buildPdfSrc(){
  if(isDuaIndex(currentSurahIndex)) return null; // no PDFs for duas
  return `Surah PDFs/${pad3(currentSurahIndex+1)}.pdf`;
}

/* ---------- Load & Play ---------- */
function loadAudio({resumeFromPercentage=false}={}){
  audio.src = buildAudioSrc();
  audio.loop = !!loopToggle.checked;
  audio.addEventListener("loadedmetadata", () => {
    if(resumeFromPercentage && isFinite(audio.duration) && audio.duration>0){
      const pct = Math.max(0,Math.min(100,currentPercentage))/100;
      audio.currentTime = pct*audio.duration;
    } else {
      audio.currentTime = 0;
    }
    audio.play().catch(()=>{});
    updateTimeLabels();
  }, { once:true });
}

/* ---------- Selection changes ---------- */
surahSearch.addEventListener("change", ()=>{
  const idx = surahList.findIndex(x => x.toLowerCase() === surahSearch.value.trim().toLowerCase());
  if(idx>=0){ surahDropdown.value=String(idx); handleSurahChange(idx); }
});
reciterSearch.addEventListener("change", ()=>{
  const idx = reciters.findIndex(r => r.name.toLowerCase() === reciterSearch.value.trim().toLowerCase());
  if(idx>=0){ reciterDropdown.value=String(idx); handleReciterChange(idx); }
});

surahDropdown.addEventListener("change", ()=> handleSurahChange(parseInt(surahDropdown.value,10)));
reciterDropdown.addEventListener("change", ()=> handleReciterChange(parseInt(reciterDropdown.value,10)));

function handleSurahChange(idx){
  currentSurahIndex = idx;
  if(repeatActive) toggleRepeat(false);
  currentPercentage = 0;
  saveSession();
  loadAudio({resumeFromPercentage:false});
  // If PDF is open, re-load PDF of the new surah
  if(!pdfStage.classList.contains("hidden")) loadPdfForCurrentSurah();
}
function handleReciterChange(idx){
  if(isFinite(audio.duration)&&audio.duration>0){
    currentPercentage = (audio.currentTime/audio.duration)*100;
  } else currentPercentage = 0;
  currentReciterIndex = idx;
  saveSession();
  loadAudio({resumeFromPercentage:true});
}

/* ---------- Transport ---------- */
playBtn.addEventListener("click", ()=>audio.play());
pauseBtn.addEventListener("click", ()=>audio.pause());
stopBtn.addEventListener("click", ()=>{ audio.pause(); audio.currentTime=0; });
nextBtn.addEventListener("click", ()=>{
  if(currentSurahIndex < surahList.length-1){
    surahDropdown.value = String(currentSurahIndex+1);
    handleSurahChange(currentSurahIndex+1);
  }
});
prevBtn.addEventListener("click", ()=>{
  if(currentSurahIndex > 0){
    surahDropdown.value = String(currentSurahIndex-1);
    handleSurahChange(currentSurahIndex-1);
  }
});
forwardBtn.addEventListener("click", ()=>{
  if(isFinite(audio.duration)) audio.currentTime = Math.min(audio.currentTime+5, audio.duration);
});
rewindBtn.addEventListener("click", ()=>{
  if(isFinite(audio.duration)) audio.currentTime = Math.max(audio.currentTime-5, 0);
});

/* ---------- Sticky bar mirrors ---------- */
barPlay.addEventListener("click", ()=>audio.play());
barPause.addEventListener("click", ()=>audio.pause());
barStop.addEventListener("click", ()=>{ audio.pause(); audio.currentTime=0; });
barFwd.addEventListener("click", ()=>{ if(isFinite(audio.duration)) audio.currentTime = Math.min(audio.currentTime+5, audio.duration); });
barRew.addEventListener("click", ()=>{ if(isFinite(audio.duration)) audio.currentTime = Math.max(audio.currentTime-5, 0); });
barNext.addEventListener("click", ()=> nextBtn.click());
barPrev.addEventListener("click", ()=> prevBtn.click());
barRead.addEventListener("click", ()=> openPdfBtn.click());

/* ---------- Progress ---------- */
let userScrubbingMain=false, userScrubbingBar=false;

progressBar.addEventListener("input", ()=>{
  userScrubbingMain=true;
  const pct = progressBar.valueAsNumber/1000;
  if(isFinite(audio.duration)&&audio.duration>0) audio.currentTime = pct*audio.duration;
  updateTimeLabels();
});
progressBar.addEventListener("change", ()=> userScrubbingMain=false);

barProgress.addEventListener("input", ()=>{
  userScrubbingBar=true;
  const pct = barProgress.valueAsNumber/1000;
  if(isFinite(audio.duration)&&audio.duration>0) audio.currentTime = pct*audio.duration;
  updateTimeLabels();
});
barProgress.addEventListener("change", ()=> userScrubbingBar=false);

audio.addEventListener("timeupdate", ()=>{
  if(!isFinite(audio.duration)||audio.duration<=0) return;

  // handle repeat segment
  if(repeatActive && audio.currentTime >= repeatEnd){
    audio.currentTime = repeatStart;
  }

  const pct = (audio.currentTime / audio.duration);
  if(!userScrubbingMain) progressBar.value = Math.round(pct*1000);
  if(!userScrubbingBar)  barProgress.value = Math.round(pct*1000);
  progressDisplay.textContent = `${(pct*100).toFixed(1)}%`;
  barTime.textContent = `${formatTime(audio.currentTime)} / ${formatTime(audio.duration)} • ${(pct*100).toFixed(1)}%`;

  // persist sometimes
  if(Math.floor(audio.currentTime)%5===0){
    localStorage.setItem("lastPercentage", String(pct*100));
  }

  // If PDF auto-sync is enabled, scroll along
  if(autoSyncToggle.checked) scrollPdfToPercentage(pct);
  updateTimeLabels();
});
audio.addEventListener("loadedmetadata", updateTimeLabels);

audio.addEventListener("ended", ()=>{
  if(repeatActive){ audio.currentTime = repeatStart; audio.play(); return; }
  if(autoNextToggle.checked){
    if(!isDuaIndex(currentSurahIndex) && currentSurahIndex < 113){
      surahDropdown.value = String(currentSurahIndex+1);
      handleSurahChange(currentSurahIndex+1);
    }
  }
});

function updateTimeLabels(){
  const cur = isFinite(audio.currentTime)?audio.currentTime:0;
  const dur = isFinite(audio.duration)?audio.duration:0;
  currentTimeEl.textContent = formatTime(cur);
  totalTimeEl.textContent = formatTime(dur);
}

/* ---------- Repeat last N seconds ---------- */
function toggleRepeat(force){
  const newState = typeof force==="boolean" ? force : !repeatActive;
  if(newState){
    const now = isFinite(audio.currentTime)?audio.currentTime:0;
    repeatEnd = now;
    repeatStart = Math.max(0, now - repeatSeconds);
    repeatActive = true;
    repeat5Btn.classList.add("primary");
    repeat5Btn.textContent = `🔁 Repeating ${repeatSeconds}s`;
    barRepeat.classList.add("primary");
  } else {
    repeatActive = false;
    repeat5Btn.classList.remove("primary");
    repeat5Btn.textContent = "🔁 Repeat";
    barRepeat.classList.remove("primary");
  }
}
repeat5Btn.addEventListener("click", ()=> toggleRepeat());
barRepeat.addEventListener("click", ()=> toggleRepeat());

/* ---------- Loop & Auto-Next ---------- */
loopToggle.addEventListener("change", ()=>{ audio.loop = !!loopToggle.checked; });
autoNextToggle.addEventListener("change", saveSession);

/* ---------- Persistence ---------- */
function saveSession(){
  let pct = 0;
  if(isFinite(audio.duration)&&audio.duration>0) pct = (audio.currentTime/audio.duration)*100;
  localStorage.setItem("lastSurahIndex", String(currentSurahIndex));
  localStorage.setItem("lastReciterIndex", String(currentReciterIndex));
  localStorage.setItem("lastPercentage", String(pct));
  localStorage.setItem("loopEnabled", loopToggle.checked ? "1":"0");
  localStorage.setItem("autoNextEnabled", autoNextToggle.checked ? "1":"0");
}
window.addEventListener("beforeunload", saveSession);

function restoreLastSession(){
  const sIdx = parseInt(localStorage.getItem("lastSurahIndex")??"0",10);
  const rIdx = parseInt(localStorage.getItem("lastReciterIndex")??"0",10);
  const pct  = parseFloat(localStorage.getItem("lastPercentage")??"0");
  const loop = localStorage.getItem("loopEnabled")==="1";
  const nxt  = localStorage.getItem("autoNextEnabled")==="1";

  if(!Number.isNaN(sIdx)&&sIdx>=0&&sIdx<surahList.length) currentSurahIndex = sIdx;
  if(!Number.isNaN(rIdx)&&rIdx>=0&&rIdx<reciters.length) currentReciterIndex = rIdx;
  currentPercentage = isFinite(pct) ? Math.max(0,Math.min(100,pct)) : 0;

  surahDropdown.value = String(currentSurahIndex);
  reciterDropdown.value = String(currentReciterIndex);
  loopToggle.checked = loop;
  autoNextToggle.checked = nxt;

  const resume = localStorage.getItem("hasLaunchedBefore") ? confirm("Resume from last session?") : false;
  localStorage.setItem("hasLaunchedBefore","1");
  loadAudio({resumeFromPercentage: resume});
}

/* =========================================================
   PDF.js — Open, Close, Render & Sync
   ========================================================= */
let pdfDoc = null;
let pdfRendering = false;

openPdfBtn.addEventListener("click", openPdfMode);
closePdfBtn.addEventListener("click", closePdfMode);

function openPdfMode(){
  document.body.classList.add("pdf-view-active");
  pdfStage.classList.remove("hidden");
  pdfStage.setAttribute("aria-hidden","false");
  loadPdfForCurrentSurah();
}
function closePdfMode(){
  document.body.classList.remove("pdf-view-active");
  pdfStage.classList.add("hidden");
  pdfStage.setAttribute("aria-hidden","true");
  // free canvases
  pdfScroll.innerHTML = "";
  pdfDoc = null;
}

/* Load current surah's PDF and render all pages */
function loadPdfForCurrentSurah(){
  const url = buildPdfSrc();
  pdfScroll.innerHTML = "";
  if(!url){
    const p = document.createElement("div");
    p.style.padding="16px"; p.style.color="#e5e7eb";
    p.textContent = "No PDF available for this selection.";
    pdfScroll.appendChild(p);
    return;
  }

  if(!window.pdfjsLib){
    const p = document.createElement("div");
    p.style.padding="16px"; p.style.color="#e5e7eb";
    p.textContent = "PDF library not found (pdf.js). Please ensure libs/pdfjs/pdf.min.js is present.";
    pdfScroll.appendChild(p);
    return;
  }

  pdfjsLib.getDocument(url).promise.then(doc=>{
    pdfDoc = doc;
    renderAllPages(doc);
    // After first render, optionally jump to current audio percent
    setTimeout(()=> { syncToCurrentAudioOnce(); }, 300);
  }).catch(err=>{
    const p = document.createElement("div");
    p.style.padding="16px"; p.style.color="#e5e7eb";
    p.textContent = "Failed to open PDF. " + err.message;
    pdfScroll.appendChild(p);
  });
}

/* Render all pages (simple approach; OK for local use) */
function renderAllPages(doc){
  const scale = 1.3; // good readability; not too wide
  const renderPage = (num)=>{
    doc.getPage(num).then(page=>{
      const viewport = page.getViewport({ scale });
      const canvas = document.createElement("canvas");
      canvas.className = "pdf-page";
      const ctx = canvas.getContext("2d");
      canvas.width = viewport.width;
      canvas.height = viewport.height;

      const renderTask = page.render({ canvasContext: ctx, viewport });
      renderTask.promise.then(()=>{
        pdfScroll.appendChild(canvas);
        if(num < doc.numPages) renderPage(num+1);
      });
    });
  };
  renderPage(1);
}

/* Mapping audio progress → scroll position */
function scrollPdfToPercentage(pct){
  if(!pdfScroll) return;
  const maxScroll = pdfScroll.scrollHeight - pdfScroll.clientHeight;
  const target = Math.max(0, Math.min(maxScroll, pct * maxScroll));
  pdfScroll.scrollTo({ top: target, behavior: "smooth" });
}

/* Sync once button */
syncOnceBtn.addEventListener("click", syncToCurrentAudioOnce);
function syncToCurrentAudioOnce(){
  if(!isFinite(audio.duration)||audio.duration<=0) return;
  const pct = audio.currentTime / audio.duration;
  scrollPdfToPercentage(pct);
}

/* =========================================================
   Sticky Control Bar — gentle auto-hide / show
   ========================================================= */
let hideTimer = null;
function scheduleHideControls(){
  clearTimeout(hideTimer);
  hideTimer = setTimeout(()=> controlBar.classList.add("hidden"), 3000);
}
function showControls(){
  controlBar.classList.remove("hidden");
  scheduleHideControls();
}
// show on start
showControls();

// Show when mouse near bottom 20% of screen
document.addEventListener("mousemove", (e)=>{
  const threshold = window.innerHeight * 0.8;
  if(e.clientY >= threshold) showControls();
});

// Also show when interacting with pdf scroll
pdfScroll.addEventListener("scroll", ()=> showControls());

/* =========================================================
   Init
   ========================================================= */
document.addEventListener("DOMContentLoaded", ()=>{
  populateSurahDropdowns();
  populateReciterDropdowns();
  restoreLastSession();
});

